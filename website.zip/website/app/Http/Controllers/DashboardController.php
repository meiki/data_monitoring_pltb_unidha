<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Dashboard;
use App\Charts\TurbinAnginChart;

use App\Charts\SampleChart;
use Charts;
use DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        
        $datas = Dashboard::orderBy('id', 'desc')->paginate(50);

        $countData = $datas->count();

        
       

        return view ('dashboard', compact('datas','countData'));
    }

    public function getData(){

        return Dashboard::all();

    }

    public function postData(Request $request){
        $data = new Dashboard;
        $data->kecepatan_angin = $request->kecepatan_angin;
        $data->voltase = $request->voltase;
        $data->arus = $request->arus;
        $data->daya = $request->daya;
        $data->putaran_poros = $request->putaran_poros;
        $data->efisiensi = $request->efisiensi;
        $data->created_at = $request->created_at;
        $data->save();

        return "Data berhasil disimpan !";
    }


    public function data(Request $req)
      {
        

        $jenisTab = $req->jenisTab;
        $jenisOpsi= $req->jenisOpsi;

        switch ($jenisOpsi) {
          case "Last60Minutes":
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subMinutes(60)->toDateTimeString())->get();
            break;
          case "Last24Hours":
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subHours(24)->toDateTimeString())->get();
            break;
          case "Last7Days":
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subWeek()->toDateTimeString())->get();
            break;
          case "Last30Days":
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subMonth()->toDateTimeString())->get();
            break;
          case "Last 12 Months":
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subMonth(12)->toDateTimeString())->get();
            break;
          case "AllYears":
            $dashboards = Dashboard::all();
            break;
          default:
            $dashboards = Dashboard::where('created_at', '>', Carbon::now()->setTimezone('Asia/Phnom_Penh')->subMinutes(60)->toDateTimeString())->get();
        }

        $dataCount = $dashboards->count();

        if($dataCount !== 0){
          foreach($dashboards as $key => $dashboard){
            $data[$key]['jenis_tab']= Dashboard::where('id',$dashboard->id)->value($jenisTab);
            $data[$key]['id']= $dashboard->id;
            $data[$key]['time']= $dashboard->created_at->format('H:i:s');   
            $data[$key]['date']=$dashboard->created_at->format('d:m:Y');
            $data[$key]['datetime']=$dashboard->created_at->format('d-M-Y H:i:s');
          }
        }else{
          for($x = 0; $x <10 ; $x++){
            $data[$x]['jenis_tab']= 0;
            $data[$x]['id']= Dashboard::latest()->first()->id;
            $data[$x]['time']= Carbon::now()->setTimezone('Asia/Phnom_Penh')->format('H:i:s');   
            $data[$x]['date']= Carbon::now()->setTimezone('Asia/Phnom_Penh')->format('d:m:Y');
            $data[$x]['dateTime']= Carbon::now()->setTimezone('Asia/Phnom_Penh')->format('d:m:Y H:i:s');
          }
            
        }
        
        return response()->json($data);
      }

    public function latestData(Request $req)
      {
        $jenisTab = "daya";
        $jenisOpsi = "Last60Minutes";
        $jenisTab = $req->jenisTab;
        $jenisOpsi = $req->jenisOpsi;
        $latestData = Dashboard::latest()->first(); 

        $data['jenis_tab'] = Dashboard::where('id',$latestData->id)->value($jenisTab);
        $data['id'] = $latestData->id;
        $data['time']= $latestData->created_at->format('H:i:s');
        $data['date']=$latestData->created_at->format('Y:m:d');
        $data['datetime']=$latestData->created_at->format('d:m:Y H:i:s');
        $data['timeNow']= Carbon::now()->setTimezone('Asia/Phnom_Penh')->format('H:i:s');

        return response()->json($data);
      }


}
