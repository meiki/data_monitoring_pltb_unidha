<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTugasakhirTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tugasakhir', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->float('kecepatan_angin');
            $table->float('voltase');
            $table->float('arus');
            $table->float('daya');
            $table->float('putaran_poros');
            $table->float('efisiensi');
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tugasakhir');
    }
}
