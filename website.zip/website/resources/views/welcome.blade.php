<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Turbin Angin Unidha</title>

  <!-- Font Awesome Icons -->
  <link href="opening/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
  <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

  <!-- Plugin CSS -->
  <link href="opening/vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

  <!-- Theme CSS - Includes Bootstrap -->
  <link href="opening/css/creative.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Masthead -->
  <header class="masthead">
    <div class="container h-100">
      <div class="row h-100 align-items-center justify-content-center text-center">
        <div class="col-lg-10 align -self-end">
          <h1 class="text-uppercase text-white font-weight-bold">Selamat Datang di Web Data Monitoring Turbin Angin Unidha</h1>
          <hr class="divider my-4">
        </div>
        <div class="col-lg-8 align-self-baseline">
          <p class="text-white-75 font-weight-light mb-5">Sebuah Web yang dibuat untuk menunjukkan data monitoring Turbin Angin yang dikembangkan oleh Tim Turbin Angin Teknik Mesin Universitas Dharma Andalas Angkatan Pertama </p>
          <a class="btn btn-primary btn-xl js-scroll-trigger" href="{{ route('dashboard') }}">AYO MULAI!</a>
        </div>
      </div>
    </div>
  </header>
</body>

</html>