<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Data Monitoring</title>

    <!-- Fontfaces CSS-->
    <link href="<?php echo e(asset('/admin/css/font-face.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/font-awesome-4.7/css/font-awesome.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/font-awesome-5/css/fontawesome-all.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/mdi-font/css/material-design-iconic-font.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="<?php echo e(asset('/admin/vendor/bootstrap-4.1/bootstrap.min.css')); ?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?php echo e(asset('/admin/vendor/animsition/animsition.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/wow/animate.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/css-hamburgers/hamburgers.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/slick/slick.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/select2/select2.min.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('/admin/vendor/perfect-scrollbar/perfect-scrollbar.css')); ?>" rel="stylesheet" media="all">
    <script src="<?php echo e(asset('/js/chartjs.min.js')); ?>" charset="utf-8"></script>

    <!-- Main CSS-->
    <link href="<?php echo e(asset('/admin/css/theme.css')); ?>" rel="stylesheet" media="all">
</head> 

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER DESKTOP-->
        <header class="header-desktop3 d-none d-lg-block">
            <div class="section__content section__content--p35">
                <div class="header3-wrap">
                    <div class="header__logo">
                        <a href="#">
                            <img src="admin/images/logos.png" alt="CoolAdmin" />
                        </a>
                    </div>
                    <div class="header__navbar">
                        <ul class="list-unstyled">
                            <li class="has-sub">
                                <a href="#">
                                    <i class="fas fa-male"></i>Biodata Tim
                                    <span class="bot-line"></span>
                                </a>
                                <ul class="header3-sub-list list-unstyled">
                                    <li>
                                        <a href="index.html">Fahrul Zikri</a>
                                    </li>
                                    <li>
                                        <a href="index2.html">Haikal Malik P</a>
                                    </li>
                                    <li>
                                        <a href="index3.html">Edo Pratama</a>
                                    </li>                                    
                                </ul>
                            </li>                            
                            <li>
                                <a href="table.html">
                                    <i class="fas fa-trophy"></i>
                                    <span class="bot-line"></span>Tentang</a>
                            </li>                            
                        </ul>
                    </div>
                    <div class="header__tool">
                        <div class="header-button-item js-item-menu">
                            <i class="zmdi zmdi-settings"></i>
                            <div class="setting-dropdown js-dropdown">
                                <div class="account-dropdown__body">
                                    <div class="account-dropdown__item">
                                        <a href="#">
                                            <i class="zmdi zmdi-account"></i>Kontak Admin</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </header>
        <!-- END HEADER DESKTOP-->

        <!-- HEADER MOBILE-->
        <header class="header-mobile header-mobile-2 d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="admin/images/icon/logo-white.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-user"></i>Biodata Tim</a>
                            <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                <li>
                                    <a href="index.html">Fahrul Zikri</a>
                                </li>
                                <li>
                                    <a href="index2.html">Haikal Malik P</a>
                                </li>
                                <li>
                                    <a href="index3.html">Edo Pratama</a>
                                </li>                                
                            </ul>
                        </li>
                        <li>
                            <a href="chart.html">
                                <i class="fas fa-tablet"></i>Tentang</a>
                        </li>                 
                    </ul>
                </div>
            </nav>
        </header>
        <div class="sub-header-mobile-2 d-block d-lg-none">
            <div class="header__tool">
                
                <div class="header-button-item js-item-menu">
                    <i class="zmdi zmdi-settings"></i>
                    <div class="setting-dropdown js-dropdown">
                        <div class="account-dropdown__body">
                            <div class="account-dropdown__item">
                                <a href="#">
                                    <i class="zmdi zmdi-account"></i>Kontak Admin</a>
                            </div>
                            
                        </div>
                    </div>
                </div>  
            </div>
        </div>
        <!-- END HEADER MOBILE -->

        <!-- PAGE CONTENT-->
        <div class="page-content--bgf7">
            <!-- BREADCRUMB-->
            <section class="au-breadcrumb2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="au-breadcrumb-content">
                                <div class="au-breadcrumb-left">
                                    <span class="au-breadcrumb-span">You are here:</span>
                                    <ul class="list-unstyled list-inline au-breadcrumb__list">
                                        <li class="list-inline-item active">
                                            <a href="#">Home</a>
                                        </li>
                                        <li class="list-inline-item seprate">
                                            <span>/</span>
                                        </li>
                                        <li class="list-inline-item">Dashboard</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END BREADCRUMB-->

            <!-- WELCOME-->
            <section class="welcome p-t-10">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h1 class="title-4">Rata-rata Data
                                <span>Turbin Angin Unidha</span>
                            </h1>
                            <hr class="line-seprate">
                        </div>
                    </div>
                </div>
            </section>
            <!-- END WELCOME-->

            <!-- STATISTIC-->
            <section class="statistic statistic2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-lg-3">
                            <div class="statistic__item statistic__item--green">

                                <?php if($countData !== 0): ?>
                                
                                    <?php 
                                        $totalData = $datas->count();
                                        $countKecAngin =0;   /* memberi nilai nol pdi awal pada  var kec angin */
                                        $countVolt = 0;
                                        $countRpm = 0; 
                                        $countDaya = 0;
                                        
                                    
                                        /* looping untuk data table tugas akhir  */
                                            foreach($datas as $data)
                                            {
                                                $countKecAngin = $countKecAngin + $data->kecepatan_angin; /* menjumlahkan kec angin */
                                                $countVolt = $countVolt + $data->voltase;
                                                $countRpm = $countRpm + $data->putaran_poros;
                                                $countDaya = $countDaya + $data->daya;
                                            }

                                            $kecAnginRata2 = number_format($countKecAngin/$totalData, 2, '.', ','); 
                                            $voltRata2 = number_format($countVolt/$totalData, 2, '.', ',');
                                            $rpmRata2 = number_format($countRpm/$totalData, 0, '.', ',');
                                            $dayaRata2 = number_format($countDaya/$totalData, 2, '.', ','); 
                                    ?>

                                <?php endif; ?>

                                
                                <?php if($countData !== 0): ?>
                                    <h2 class="number"><?php echo e($kecAnginRata2); ?> m/s</h2>
                                <?php else: ?>
                                    <h2 class="number">0 m/s</h2>
                                <?php endif; ?>
                                <span class="desc">Kecepatan Angin</span>
                                <div class="icon">
                                    <i class="zmdi zmdi-account-o"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="statistic__item statistic__item--orange">
                                <?php if($countData !== 0): ?>
                                    <h2 class="number"><?php echo e($voltRata2); ?> Volt</h2>
                                <?php else: ?>
                                    <h2 class="number">0 Volt</h2>
                                <?php endif; ?>
                                <span class="desc">Voltase</span>
                                <div class="icon">
                                    <i class="zmdi zmdi-shopping-cart"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="statistic__item statistic__item--blue">
                                <?php if($countData !== 0): ?>
                                    <h2 class="number"><?php echo e($rpmRata2); ?> rpm</h2>
                                <?php else: ?>
                                    <h2 class="number">0 rpm</h2>
                                <?php endif; ?>
                                <span class="desc">RPM Poros</span>
                                <div class="icon">
                                    <i class="zmdi zmdi-calendar-note"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3">
                            <div class="statistic__item statistic__item--red">
                                <?php if($countData !== 0): ?>
                                    <h2 class="number"><?php echo e($dayaRata2); ?> W</h2>
                                <?php else: ?>
                                    <h2 class="number">0 W</h2>
                                <?php endif; ?>

                                <span class="desc">Daya</span>
                                <div class="icon">
                                    <i class="zmdi zmdi-money"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END STATISTIC-->


            


            <!-- GRAFIK DATA -->

            <section class="p-t-20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="title-5 m-b-35">Grafik Data</h3>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="tabs">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item"><a class="nav-link active" href="#daya">Daya</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#voltase">Voltase</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#arus">Arus</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#efisiensi">Efisiensi</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#kecepatan_angin">Kecepatan Angin</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#putaran_poros">Putaran Poros</a></li>
                                    
                                </ul>
                                <!-- Tab panes -->
                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade mb-3 show active" id="daya" role="tabpanel" aria-labelledby="daya-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last12Months">Last 12 Months</option>
                                                    <option id="AllYears">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">  
                                                        <canvas id="dayaChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane mb-3" id="voltase" role="tabpanel" aria-labelledby="voltase-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last 12 Months">Last 12 Months</option>
                                                    <option id="AllYearsVolt">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">
                                                        <canvas id="voltaseChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane mb-3" id="arus" role="tabpanel" aria-labelledby="arus-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last 12 Months">Last 12 Months</option>
                                                    <option id="AllYearsVolt">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">
                                                        <canvas id="arusChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane mb-3" id="efisiensi" role="tabpanel" aria-labelledby="efisiensi-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last 12 Months">Last 12 Months</option>
                                                    <option id="AllYearsVolt">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">
                                                        <canvas id="efisiensiChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane mb-3" id="kecepatan_angin" role="tabpanel" aria-labelledby="kecepatan-angin-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last 12 Months">Last 12 Months</option>
                                                    <option id="AllYearsVolt">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">
                                                        <canvas id="kecepatan_anginChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane mb-3" id="putaran_poros" role="tabpanel" aria-labelledby="putaran-poros-tab">
                                        <div class="row">
                                            <div class="col-md-12 m-3">
                                                <div class="form-group col-md-3 pull-right">
                                                    <select id="jenisOpsi" class="form-control">
                                                    <option id="Last60Minutes" selected>Last 60 Minutes</option>
                                                    <option id="Last24Hours">Last 24 Hours</option>
                                                    <option id="Last7Days">Last 7 Days</option>
                                                    <option id="Last30Days">Last 30 Days</option>
                                                    <option id="Last 12 Months">Last 12 Months</option>
                                                    <option id="AllYearsVolt">All Years</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="panel panel-default">
                                                    <div class="panel-body">
                                                        <canvas id="putaran_porosChart" height="350px" width="800px"></canvas>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>




                </div>
            </section>

            <!-- END GRAFIK DATA -->




             <!-- DATA TABLE-->
             <section class="p-t-20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <h3 class="title-5 m-b-35">data table</h3>
                            <div class="table-responsive table-responsive-data2">
                                <table id="data" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Waktu</th>
                                            <th>Kecepatan Angin</th>
                                            <th>Voltase</th>
                                            <th>Arus</th>
                                            <th>Daya</th>
                                            <th>Putaran Poros</th>
                                            <th>Efisiensi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($countData !== 0): ?>
                                            <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($data->created_at->format('d M Y H:m:i')); ?></td>
                                                    <td><?php echo e($data->kecepatan_angin); ?> </td>
                                                    <td><?php echo e($data->voltase); ?> </td>
                                                    <td><?php echo e($data->arus); ?> </td>
                                                    <td><?php echo e($data->daya); ?> </td>
                                                    <td><?php echo e($data->putaran_poros); ?> </td>
                                                    <td><?php echo e($data->efisiensi); ?> % </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                        
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                            <div class="row justify-content-center mt-3"> <?php echo e($datas->links()); ?></div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END DATA TABLE-->

            

            <!-- COPYRIGHT-->
            <section class="p-t-60 p-b-20">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="copyright">
                                <p>Copyright © 2019 Unidha Wind Turbin Team. All rights reserved. </p>
                        </div>
                    </div>
                </div>
            </section>
            <!-- END COPYRIGHT-->
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="<?php echo e(asset('/admin/vendor/jquery-3.2.1.min.js')); ?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-4.1/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-4.1/bootstrap.min.js')); ?>"></script>
    <!-- Vendor JS       -->
    <script src="<?php echo e(asset('/admin/vendor/slick/slick.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/animsition/animsition.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/counter-up/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/counter-up/jquery.counterup.min.js')); ?>">
    </script>
    <script src="<?php echo e(asset('/admin/vendor/circle-progress/circle-progress.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/select2/select2.min.js')); ?>">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js" charset="utf-8"></script>
    <script src="<?php echo e(asset('/admin/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/admin/vendor/dataTables.bootstrap.min.js')); ?>"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/4.0.2/echarts-en.min.js" charset="utf-8"></script>

    </script>

    <!-- Main JS-->
    <script src="admin/js/main.js"></script>
    <script type="text/javascript">

        $(document).ready(function() {
          $('#group').DataTable({
                        responsive: true,
                        autoWidth: false
             });
            
            
            
        } );

    </script>
    
    <script>
        $(document).ready(function(){
            
            var jenisTab = "";
            var jenisOpsi = "";
            var satuan = "";
           

            var SumbuX = new Array();
            var SumbuY = new Array();
            var ID = new Array();
            var data = new Array();
            var namaChart = "daya";

            function clearData(){
                SumbuX = [];
                SumbuY = [];
                ID = [];
            }
            
            getTabActive();
            getOpsiActive();

            function getSatuan(){
                switch(jenisTab){
                    case 'daya':
                        satuan = "Watt";
                        break;
                    case 'voltase':
                        satuan = "Volt";
                        break;
                    case 'arus':
                        satuan = "Amper";
                        break;
                    case 'efisiensi':
                        satuan = '%';
                        break;
                    case 'kecepatan_angin':
                        satuan = "m/s";
                        break;
                    case 'putaran_poros':
                        satuan = "rpm";
                        break;
                    default:
                        satuan = "";
                }
            }
            
            function getTabActive(){
                jenisTab = $('#myTab a.active').attr("href").replace("#", "");
                
                
            }

            function getOpsiActive(){
                jenisOpsi = $('#'+jenisTab+' #jenisOpsi option:selected').attr('id');
                
                clearData();
                getData(jenisTab, jenisOpsi);
            }

            $('#myTab a').on('click', function (e) {
                e.preventDefault()
                $(this).tab('show')

                getTabActive();
                getOpsiActive();
            })

            $('#jenisOpsi option').on('click', function (e) {
                    e.preventDefault()
                    getOpsiActive();
            })

            

            function getData(jenisTab, jenisOpsi){
                $.ajax({
                    type: "POST",
                    url:"<?php echo e(url('/grafik/data')); ?>",
                    data : {
                        _token:"<?php echo e(csrf_token()); ?>",
                        jenisTab : jenisTab,
                        jenisOpsi : jenisOpsi,
                    },
                    success : function(response){

                        
                        
                        response.forEach(function(data){
                            SumbuX.push(data.datetime);
                            SumbuY.push(data.jenis_tab);
                            ID.push(data.id);
                        });

                        namaChart = jenisTab+"Chart";
                        var ctx = document.getElementById(namaChart).getContext('2d');
                        data = {
                            labels: SumbuX,
                            datasets: [{
                                id: ID,
                                label: jenisTab,
                                data: SumbuY,
                                borderWidth: 1
                            }]
                        };

                        getSatuan();

                        var options = {
                            
                            animation: false,
                            //Boolean - If we want to override with a hard coded scale
                            scaleOverride: true,
                            //** Required if scaleOverride is true **
                            //Number - The number of steps in a hard coded scale
                            scaleSteps: 10,
                            //Number - The value jump in the hard coded scale
                            scaleStepWidth: 10,
                            //Number - The scale starting value
                            scaleStartValue: 0,

                            showTooltips: false,

                            legend: {
                                display: false
                            },

                            scales: {
                                yAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: jenisTab+' ('+satuan+') '
                                    }
                                }],
                                xAxes: [{
                                    scaleLabel: {
                                        display: true,
                                        labelString: 'Tanggal & Waktu'
                                    }
                                }]
                            }     
                        };

                        var myChart = new Chart(ctx, {
                            type: 'line',
                            data: data,
                            options: options
                        });

                        setInterval(function() {
                            getLatestData();

                            var myChart = new Chart(ctx, {
                                type: 'line',
                                data: data,
                                options: options
                            });
            
                        }, 10000);

                        //console.log(SumbuX+' - '+SumbuY) ;   
                    }
                });
            }

            function getLatestData(){
                $.ajax({
                    type: "POST",
                    url:"<?php echo e(url('/grafik/latestdata')); ?>",
                    data : {
                        _token:"<?php echo e(csrf_token()); ?>",
                        jenisTab : jenisTab,
                        jenisOpsi : jenisOpsi,
                    },
                    success : function(latest){

                        if(ID[ID.length-1] < latest.id){
                            data.labels.push(latest.time);
                            data.datasets.forEach((dataset) => {
                                dataset.data.push(latest.jenis_tab);
                                if(ID.length > 720){
                                    dataset.data.shift();
                                }
                            });
                            
                            ID.push(latest.id);
                            if(ID.length > 720){
                                data.labels.shift();
                                ID.shift();
                            }  
                        }else{
                            data.labels.push(latest.timeNow);
                            if(ID.length > 720){
                                data.labels.shift();
                                ID.shift();
                            }
                            data.datasets.forEach((dataset) => {
                                dataset.data.push(0);
                                if(ID.length > 720){
                                    dataset.data.shift();
                                }
                            });
                        }
                        
                        //console.log(latest) ;   
                    }
                });

            }


        })        
        
    </script>

</body>

</html>
<!-- end document-->
    

<?php /**PATH /home2/teknikmesin/public_html/pltb/turbin/resources/views/dashboard.blade.php ENDPATH**/ ?>